package dev.autodrill;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

public final class DrillGui implements InventoryHolder {
    public static final int[] SIZES = {1, 3, 5, 7, 9};
    public static final int[] SIZE_SLOTS = {10, 11, 12, 13, 14};
    public static final int[] RATES = {4, 8, 16, 32};
    public static final int[] RATE_SLOTS = {19, 20, 21, 22};
    public static final int[] DEPTHS = {16, 32, 64};
    public static final int[] DEPTH_SLOTS = {24, 25, 26};
    public static final int TOGGLE_SLOT = 16;

    private final Inventory inv;

    public DrillGui(Session s) {
        inv = Bukkit.createInventory(this, 27,
                Component.text("\u26CF Auto Drill", NamedTextColor.GOLD, TextDecoration.BOLD));
        render(s);
    }

    public void render(Session s) {
        ItemStack pane = item(Material.GRAY_STAINED_GLASS_PANE, " ", false);
        for (int i = 0; i < 27; i++) inv.setItem(i, pane);

        inv.setItem(1, item(Material.NETHERITE_PICKAXE, "Hole size", false,
                "Pick the width/height of the hole."));
        for (int i = 0; i < SIZES.length; i++) {
            int n = SIZES[i];
            inv.setItem(SIZE_SLOTS[i], item(Material.DIAMOND_PICKAXE, n + " x " + n, s.size == n,
                    s.size == n ? "Selected" : "Click to select"));
        }
        inv.setItem(18, item(Material.CLOCK, "Speed (blocks/sec)", false));
        for (int i = 0; i < RATES.length; i++) {
            int r = RATES[i];
            inv.setItem(RATE_SLOTS[i], item(Material.REDSTONE, r + " /s", s.rate == r,
                    s.rate == r ? "Selected" : "Click to select"));
        }
        inv.setItem(23, item(Material.SPYGLASS, "Depth", false));
        for (int i = 0; i < DEPTHS.length; i++) {
            int d = DEPTHS[i];
            inv.setItem(DEPTH_SLOTS[i], item(Material.IRON_INGOT, d + " blocks", s.depth == d,
                    s.depth == d ? "Selected" : "Click to select"));
        }
        if (s.active) {
            inv.setItem(TOGGLE_SLOT, item(Material.RED_CONCRETE, "STOP drill", true,
                    "Size/depth locked while running."));
        } else {
            inv.setItem(TOGGLE_SLOT, item(Material.LIME_CONCRETE, "START drill", true,
                    "Digs in the direction you face.",
                    "Look down to dig straight down."));
        }
    }

    private static ItemStack item(Material m, String name, boolean glow, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Component.text(name, NamedTextColor.YELLOW)
                .decoration(TextDecoration.ITALIC, false));
        if (lore.length > 0) {
            meta.lore(java.util.Arrays.stream(lore)
                    .map(l -> Component.text(l, NamedTextColor.GRAY)
                            .decoration(TextDecoration.ITALIC, false))
                    .toList());
        }
        if (glow) meta.setEnchantmentGlintOverride(true);
        it.setItemMeta(meta);
        return it;
    }

    @Override
    public Inventory getInventory() {
        return inv;
    }
}
