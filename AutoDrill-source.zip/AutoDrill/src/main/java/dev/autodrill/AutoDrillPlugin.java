package dev.autodrill;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class AutoDrillPlugin extends JavaPlugin implements Listener, CommandExecutor {

    private final Map<UUID, Session> sessions = new HashMap<>();

    @Override
    public void onEnable() {
        getCommand("drill").setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, this);
        Bukkit.getScheduler().runTaskTimer(this, this::tick, 1L, 1L);
    }

    private Session session(Player p) {
        return sessions.computeIfAbsent(p.getUniqueId(), k -> new Session());
    }

    private static void msg(Player p, String text, NamedTextColor c) {
        p.sendMessage(Component.text("[Drill] ", NamedTextColor.GOLD)
                .append(Component.text(text, c)));
    }

    /* ---------------- command ---------------- */

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Players only.");
            return true;
        }
        Session s = session(p);
        if (args.length > 0 && args[0].equalsIgnoreCase("stop")) {
            if (s.active) stop(p, s, "Drill stopped.");
            return true;
        }
        p.openInventory(new DrillGui(s).getInventory());
        return true;
    }

    /* ---------------- GUI ---------------- */

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof DrillGui) e.setCancelled(true);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof DrillGui gui)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != e.getInventory()) return;

        Session s = session(p);
        int slot = e.getSlot();

        if (slot == DrillGui.TOGGLE_SLOT) {
            if (s.active) {
                stop(p, s, "Drill stopped.");
            } else {
                start(p, s);
                p.closeInventory();
                return;
            }
        } else {
            for (int i = 0; i < DrillGui.SIZE_SLOTS.length; i++)
                if (slot == DrillGui.SIZE_SLOTS[i]) {
                    if (s.active) { msg(p, "Stop the drill to change size.", NamedTextColor.RED); return; }
                    s.size = DrillGui.SIZES[i];
                }
            for (int i = 0; i < DrillGui.DEPTH_SLOTS.length; i++)
                if (slot == DrillGui.DEPTH_SLOTS[i]) {
                    if (s.active) { msg(p, "Stop the drill to change depth.", NamedTextColor.RED); return; }
                    s.depth = DrillGui.DEPTHS[i];
                }
            for (int i = 0; i < DrillGui.RATE_SLOTS.length; i++)
                if (slot == DrillGui.RATE_SLOTS[i]) s.rate = DrillGui.RATES[i];
        }
        gui.render(s);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        sessions.remove(e.getPlayer().getUniqueId());
    }

    /* ---------------- drill logic ---------------- */

    private void start(Player p, Session s) {
        Location l = p.getLocation();
        s.dir = l.getPitch() > 60 ? BlockFace.DOWN : p.getFacing();
        s.origin = new Location(l.getWorld(), l.getBlockX() + 0.5, l.getBlockY(), l.getBlockZ() + 0.5);
        s.layer = 1;
        s.cell = 0;
        s.budget = 0;
        s.active = true;
        msg(p, "Drilling " + s.size + "x" + s.size + ", " + s.depth + " deep ("
                + s.dir.name().toLowerCase() + "). /drill stop to cancel.", NamedTextColor.GREEN);
    }

    private void stop(Player p, Session s, String why) {
        s.active = false;
        msg(p, why, NamedTextColor.YELLOW);
    }

    private void tick() {
        for (Map.Entry<UUID, Session> e : sessions.entrySet()) {
            Session s = e.getValue();
            if (!s.active) continue;
            Player p = Bukkit.getPlayer(e.getKey());
            if (p == null || !p.isOnline()) { s.active = false; continue; }
            run(p, s);
        }
    }

    private void run(Player p, Session s) {
        if (s.layer > s.depth) { stop(p, s, "Drill finished."); return; }
        if (!p.getWorld().equals(s.origin.getWorld())) { stop(p, s, "World changed - stopped."); return; }

        // Auto-move: follow the dig face smoothly until we're in position.
        Location stand = standPos(s, s.layer);
        if (p.getLocation().distance(stand) > 0.6) {
            move(p, stand, s);
            return;
        }

        s.budget += s.rate / 20.0;
        int guard = 0;
        while (s.budget >= 1 && guard++ < 200) {
            Block b = cellBlock(s, s.layer, s.cell);
            if (nextToLava(b)) { stop(p, s, "Stopped: lava ahead."); return; }

            boolean broke = false;
            Material t = b.getType();
            if (!t.isAir() && !b.isLiquid() && t.getHardness() >= 0) {
                if (p.breakBlock(b)) {
                    broke = true;
                    b.getWorld().spawnParticle(Particle.CRIT, b.getLocation().add(0.5, 0.5, 0.5), 4, 0.2, 0.2, 0.2, 0.05);
                }
            }
            if (broke) s.budget -= 1;

            if (++s.cell >= s.cellCount()) {
                s.cell = 0;
                s.layer++;
                break; // layer done; move up next tick
            }
        }
    }

    private Location standPos(Session s, int layer) {
        Vector d = new Vector(s.dir.getModX(), s.dir.getModY(), s.dir.getModZ());
        return s.origin.clone().add(d.multiply(layer - 1));
    }

    private Block cellBlock(Session s, int layer, int cell) {
        int half = s.size / 2;
        int i = cell % s.size;
        int j = cell / s.size;
        World w = s.origin.getWorld();
        int bx = s.origin.getBlockX(), by = s.origin.getBlockY(), bz = s.origin.getBlockZ();
        if (s.dir == BlockFace.DOWN) {
            return w.getBlockAt(bx + (j - half), by - layer, bz + (i - half));
        }
        int x = bx + s.dir.getModX() * layer;
        int z = bz + s.dir.getModZ() * layer;
        int lat = i - half;
        if (s.dir.getModX() == 0) x += lat; else z += lat;
        return w.getBlockAt(x, by + j, z);
    }

    private static final BlockFace[] SIDES = {
            BlockFace.UP, BlockFace.DOWN, BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST};

    private boolean nextToLava(Block b) {
        for (BlockFace f : SIDES) if (b.getRelative(f).getType() == Material.LAVA) return true;
        return false;
    }

    /** Smooth movement + smooth turning toward the dig direction. */
    private void move(Player p, Location stand, Session s) {
        Location cur = p.getLocation();
        Vector delta = stand.toVector().subtract(cur.toVector());
        double len = delta.length();
        Location next = cur.clone();
        if (len > 1e-4) next.add(delta.normalize().multiply(Math.min(0.25, len)));

        float targetYaw = switch (s.dir) {
            case SOUTH -> 0f; case WEST -> 90f; case NORTH -> 180f; case EAST -> -90f; default -> cur.getYaw();
        };
        float targetPitch = s.dir == BlockFace.DOWN ? 80f : 0f;
        next.setYaw(cur.getYaw() + clamp(wrap(targetYaw - cur.getYaw()), 12f));
        next.setPitch(cur.getPitch() + clamp(targetPitch - cur.getPitch(), 8f));
        p.teleport(next);
    }

    private static float wrap(float a) {
        a %= 360f;
        if (a > 180f) a -= 360f;
        if (a < -180f) a += 360f;
        return a;
    }

    private static float clamp(float v, float max) {
        return Math.max(-max, Math.min(max, v));
    }
}
