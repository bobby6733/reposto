package dev.autodrill;

import org.bukkit.Location;
import org.bukkit.block.BlockFace;

/** Per-player drill settings and progress. */
public final class Session {
    public int size = 3;     // 1,3,5,7,9  -> NxN hole
    public int depth = 32;   // how many layers to dig
    public int rate = 8;     // blocks per second (smooth, not instant)

    boolean active;
    BlockFace dir;
    Location origin;
    int layer = 1;
    int cell = 0;
    double budget = 0;

    /** Horizontal tunnels are at least 2 tall so the player fits. */
    int rows() {
        return dir == BlockFace.DOWN ? size : Math.max(size, 2);
    }

    int cellCount() {
        return size * rows();
    }
}
